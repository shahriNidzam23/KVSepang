//import firebase from 'firebase/app'

const config = {
    apiKey: "AIzaSyBKDJ6qVHk4sb_L1NkdUA2QyrHu6sS7gx4",
    authDomain: "my-r-pocket.firebaseapp.com",
    databaseURL: "https://my-r-pocket.firebaseio.com",
    projectId: "my-r-pocket",
    storageBucket: "my-r-pocket.appspot.com",
    messagingSenderId: "844671207814",
    appId: "1:844671207814:web:78980eacd7e8bdae"
  };

export default config